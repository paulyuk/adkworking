var dbConfig = module.exports = {};

dbConfig.database = {
    id: 'BulletinBoard',
    containerId: 'Events'
};