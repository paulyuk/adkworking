var cosmosDbConfig = module.exports = {};

cosmosDbConfig.connection = {
    endpoint: '',
    key: ''
};